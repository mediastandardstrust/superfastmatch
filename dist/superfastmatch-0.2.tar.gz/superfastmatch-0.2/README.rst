README
======

SuperFastMatch depends on `Paver <http://paver.github.com/paver/#installation>`_ and `VirtualEnv <http://pypi.python.org/pypi/virtualenv>`_  to get bootstrapped. 

After install:

``paver help``

will display options with the custom commands visible last. After that it might be worth having a look at the `Developing <http://mediastandardstrust.github.com/superfastmatch/developing.html>`_ page.